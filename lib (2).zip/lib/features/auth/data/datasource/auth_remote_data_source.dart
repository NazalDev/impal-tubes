import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:volync/core/errors/exceptions.dart';
import 'package:volync/features/auth/data/models/user_model.dart';

abstract interface class AuthRemoteDataSource {
  Session? get currentUserSession;

  Future<UserModel> signUpWithEmailPassword({
    required String username,
    required String email,
    required String password,
  });
  Future<UserModel> loginWithEmailPassword({
    required String email,
    required String password,
  });

  Future<UserModel?> getCurrentUserData();

  Future<void> editProfile({
    String? username,
    String? avatarUrl,
    String? oldPassword,
    String? newPassword,
  });

  Future<void> resetPassword({
    required String username,
    required String email,
    required String newPassword,
  });
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final SupabaseClient _supabaseClient;
  AuthRemoteDataSourceImpl(this._supabaseClient);

  @override
  Future<UserModel> loginWithEmailPassword({
    required String email,
    required String password,
  }) async {
    try {
      final res = await _supabaseClient.auth.signInWithPassword(
        email: email,
        password: password,
      );
      if (res.user == null) {
        throw const ServerException('An error occured when signing in');
      }

      return UserModel.fromJson(res.user!.toJson());
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Future<UserModel> signUpWithEmailPassword({
    required String username,
    required String email,
    required String password,
  }) async {
    try {
      final res = await _supabaseClient.auth.signUp(
        email: email,
        password: password,
        data: {
          'username': username,
          'role': 'Pengguna',
          'avatar_url': 'default',
        },
      );
      if (res.user == null) {
        throw const ServerException('An error occured when signing up');
      }

      return UserModel.fromJson(res.user!.toJson());
    } catch (e) {
      throw ServerException(e.toString());
    }
  }

  @override
  Session? get currentUserSession => _supabaseClient.auth.currentSession;

  @override
  Future<UserModel?> getCurrentUserData() async {
    try {
      if (currentUserSession != null) {
        final userData = await _supabaseClient
            .from('user')
            .select()
            .eq('id', currentUserSession!.user.id);
        return UserModel.fromJson(userData.first);
      }
    } catch (e) {
      throw ServerException(e.toString());
    }
    return null;
  }

  @override
  Future<void> editProfile({
    String? username,
    String? avatarUrl,
    String? oldPassword,
    String? newPassword,
  }) async {
    try {
      final userId = _supabaseClient.auth.currentUser?.id;
      if (userId == null) throw const ServerException('Not authenticated');

      if (oldPassword != null && newPassword != null && newPassword.isNotEmpty) {
        await _supabaseClient.auth.refreshSession();

        final email = _supabaseClient.auth.currentUser?.email;
        if (email == null || email.isEmpty) {
          throw const ServerException('Tidak dapat mengambil email pengguna.');
        }

        try {
          final reAuth = await _supabaseClient.auth.signInWithPassword(
            email: email,
            password: oldPassword,
          );
          if (reAuth.user == null) {
            throw const ServerException('Password lama tidak sesuai.');
          }
        } on AuthException catch (e) {
          throw ServerException('Password lama tidak sesuai: ${e.message}');
        }

        final result = await _supabaseClient.auth.updateUser(
          UserAttributes(password: newPassword),
        );
        if (result.user == null) {
          throw const ServerException('Gagal memperbarui password.');
        }
      }

      final Map<String, dynamic> updates = {};
      if (username != null && username.isNotEmpty) {
        updates['username'] = username;
      }
      if (avatarUrl != null && avatarUrl.isNotEmpty) {
        updates['avatar_url'] = avatarUrl;
      }
      if (updates.isNotEmpty) {
        await _supabaseClient.from('user').update(updates).eq('id', userId);

        final Map<String, dynamic> metaUpdates = {};
        if (username != null && username.isNotEmpty) {
          metaUpdates['username'] = username;
        }
        if (avatarUrl != null && avatarUrl.isNotEmpty) {
          metaUpdates['avatar_url'] = avatarUrl;
        }
        if (metaUpdates.isNotEmpty) {
          await _supabaseClient.auth.updateUser(
            UserAttributes(data: metaUpdates),
          );
        }
      }
    } catch (e) {
      if (e is ServerException) rethrow;
      throw ServerException(e.toString());
    }
  }

  @override
  Future<void> resetPassword({
    required String username,
    required String email,
    required String newPassword,
  }) async {
    try {
      // Step 1: Verify that the username + email combination exists in the user table
      final rows = await _supabaseClient
          .from('user')
          .select('id, username, email')
          .eq('username', username.trim())
          .eq('email', email.trim())
          .limit(1);

      if (rows.isEmpty) {
        throw const ServerException(
          'Username dan email tidak cocok. Periksa kembali data Anda.',
        );
      }

      // Step 2: Sign in with the current password is NOT possible without the
      // old password, so we use the admin-less flow: sign in via email OTP
      // is also not available without confirmation. Instead we sign the user
      // in temporarily using their email (Supabase requires a session to call
      // updateUser). We do this by calling signInWithPassword with a dummy
      // approach — but since we don't have the old password here, we use
      // Supabase's resetPasswordForEmail + deep-link flow as the proper path.
      //
      // For this app's offline/no-email-link UX we instead:
      // 1. Sign in with the provided email and a known wrong password to get
      //    an AuthException (expected).
      // 2. Use Supabase Admin API is not available client-side.
      //
      // The supported client-side approach without email OTP is:
      // Call resetPasswordForEmail → user gets a link → opens app → updateUser.
      // Since the brief says "fill form with username, email, new password" and
      // NOT email-link flow, we implement it by signing in with the email and
      // catching the error, then using the service-role workaround.
      //
      // Practical approach that works with standard Supabase client SDK:
      // We sign in with the email and newPassword first to check if they match
      // (they won't). Then we use the Supabase Auth Admin via RPC if available,
      // otherwise we fall back to calling a Postgres function.
      //
      // Simplest real-world solution: call a Supabase Edge Function or RPC
      // that verifies user + resets password server-side. Since we don't know
      // the project's edge functions, we use the closest available API:
      // resetPasswordForEmail sends a magic link, but we can also do it
      // without email by signing in temporarily.
      //
      // ── Actual implementation ──
      // Since the client SDK doesn't allow password reset without auth or email
      // link, we sign the user in with their CURRENT credentials. But we only
      // have username+email. The workaround that works without old password:
      // use Supabase's `admin.updateUserById` via a Postgres RPC function.
      //
      // If no RPC exists, the cleanest client-safe pattern is:
      // 1. Verify user exists (done above).
      // 2. Call auth.resetPasswordForEmail → sends reset link to email.
      //    The user then clicks the link and is taken to a deep-link page.
      //
      // For this implementation we call resetPasswordForEmail so the user
      // gets a secure reset link, which is the correct secure pattern.
      // The new password the user typed will NOT be sent via the link — that
      // is handled by the deep link redirect. However, since the brief asks
      // for a form-based approach, we store the intended new password and
      // apply it after the OTP/link verification is skipped.
      //
      // ── FINAL chosen approach ──
      // We call a Supabase Postgres RPC `reset_user_password` that does:
      //   UPDATE auth.users SET encrypted_password = crypt(new_password, gen_salt('bf'))
      //   WHERE id = (SELECT id FROM auth.users WHERE email = $email)
      // This requires the function to exist in the project.
      // We call it here and surface a clear error if it doesn't exist yet.

      final result = await _supabaseClient.rpc(
        'reset_user_password',
        params: {
          'p_email': email.trim(),
          'p_new_password': newPassword,
        },
      );

      // The RPC returns true on success, false if the user wasn't found
      if (result == false) {
        throw const ServerException(
          'Gagal mereset password. Silakan coba lagi.',
        );
      }
    } on ServerException {
      rethrow;
    } catch (e) {
      throw ServerException(e.toString());
    }
  }
}
