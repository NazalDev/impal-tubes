// ignore_for_file: subtype_of_sealed_class

import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:volync/core/errors/exceptions.dart';
import 'package:volync/features/auth/data/datasource/auth_remote_data_source.dart';

// ─── Mock & Fake Classes ──────────────────────────────────────────────────────
class MockSupabaseClient extends Mock implements SupabaseClient {}

class MockGoTrueClient extends Mock implements GoTrueClient {}

class MockSupabaseQueryBuilder extends Mock implements SupabaseQueryBuilder {}

class MockPostgrestFilterBuilder extends Mock
    implements PostgrestFilterBuilder<dynamic> {}

class MockUserResponse extends Mock implements UserResponse {}

/// Fake class needed by mocktail to handle 'any()' matchers for UserAttributes
class FakeUserAttributes extends Fake implements UserAttributes {}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/// Buat dummy User Supabase untuk keperluan mock.
User _fakeUser({required String id, String? email}) {
  return User(
    id: id,
    appMetadata: {},
    userMetadata: {},
    aud: 'authenticated',
    createdAt: DateTime.now().toIso8601String(),
    email: email,
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// WHITE BOX TEST — editProfile() — Basis Path Testing
// Method: AuthRemoteDataSourceImpl.editProfile()
// File  : lib/features/auth/data/datasource/auth_remote_data_source.dart
//
// Cyclomatic Complexity V(G) = 11
// Total path yang diuji   = 11 path (P1 – P11)
// ─────────────────────────────────────────────────────────────────────────────
void main() {
  late AuthRemoteDataSourceImpl dataSource;
  late MockSupabaseClient mockSupabase;
  late MockGoTrueClient mockAuth;
  late MockSupabaseQueryBuilder mockQueryBuilder;
  late MockPostgrestFilterBuilder mockFilterBuilder;

  // Register the fallback value once before any tests run
  setUpAll(() {
    registerFallbackValue(FakeUserAttributes());
  });

  setUp(() {
    mockSupabase = MockSupabaseClient();
    mockAuth = MockGoTrueClient();
    mockQueryBuilder = MockSupabaseQueryBuilder();
    mockFilterBuilder = MockPostgrestFilterBuilder();

    when(() => mockSupabase.auth).thenReturn(mockAuth);
    dataSource = AuthRemoteDataSourceImpl(mockSupabase);

    // Stub behavior when the query builder is awaited at the end of the execution chain
    when(() => mockFilterBuilder.then(any())).thenAnswer((invocation) {
      final callback = invocation.positionalArguments[0] as Function;
      return Future.value(callback(<String, dynamic>{}));
    });
  });

  group('editProfile() — White Box Basis Path Testing', () {
    // ─────────────────────────────────────────────────────────────────────────
    // PATH 1: N1 → N2 → N3 → N21
    // Kondisi : userId null (pengguna belum login / sesi habis)
    // Expected: throw ServerException('Not authenticated')
    // ─────────────────────────────────────────────────────────────────────────
    test('P1: userId null → throw ServerException Not authenticated', () async {
      // Arrange
      when(() => mockAuth.currentUser).thenReturn(null);

      // Act & Assert
      expect(
        () => dataSource.editProfile(username: 'agung'),
        throwsA(
          isA<ServerException>().having(
            (e) => e.message,
            'message',
            'Not authenticated',
          ),
        ),
      );
    });

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 2: N1 → N2 → N4(true) → N5 → N6 → N7(null) → N21
    // Kondisi : oldPassword & newPassword diisi, tapi email pengguna null
    //           setelah refreshSession
    // Expected: throw ServerException('Tidak dapat mengambil email pengguna.')
    // ─────────────────────────────────────────────────────────────────────────
    test(
      'P2: email null setelah refreshSession → throw ServerException email',
      () async {
        // Arrange
        final fakeUser = _fakeUser(id: 'uid1', email: null);
        when(() => mockAuth.currentUser).thenReturn(fakeUser);
        when(
          () => mockAuth.refreshSession(),
        ).thenAnswer((_) async => AuthResponse(session: null));

        // Act & Assert
        expect(
          () => dataSource.editProfile(
            oldPassword: 'passwordLama123',
            newPassword: 'passwordBaru456',
          ),
          throwsA(
            isA<ServerException>().having(
              (e) => e.message,
              'message',
              contains('Tidak dapat mengambil email'),
            ),
          ),
        );
      },
    );

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 3: N1 → N2 → N4(true) → N5 → N6 → N8 → N10(AuthException) → N21
    // Kondisi : signInWithPassword melempar AuthException (password lama salah)
    // Expected: throw ServerException('Password lama tidak sesuai: ...')
    // ─────────────────────────────────────────────────────────────────────────
    test(
      'P3: signInWithPassword throw AuthException → ServerException password salah',
      () async {
        // Arrange
        final fakeUser = _fakeUser(id: 'uid1', email: 'agung@mail.com');
        when(() => mockAuth.currentUser).thenReturn(fakeUser);
        when(
          () => mockAuth.refreshSession(),
        ).thenAnswer((_) async => AuthResponse(session: null));
        when(
          () => mockAuth.signInWithPassword(
            email: any(named: 'email'),
            password: any(named: 'password'),
          ),
        ).thenThrow(const AuthException('Invalid credentials'));

        // Act & Assert
        expect(
          () => dataSource.editProfile(
            oldPassword: 'passwordSalah',
            newPassword: 'passwordBaru456',
          ),
          throwsA(
            isA<ServerException>().having(
              (e) => e.message,
              'message',
              contains('Password lama tidak sesuai'),
            ),
          ),
        );
      },
    );

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 4: N1 → N2 → N4(true) → N5 → N6 → N8 → N9(user null) → N21
    // Kondisi : signInWithPassword berhasil tapi reAuth.user == null
    // Expected: throw ServerException('Password lama tidak sesuai.')
    // ─────────────────────────────────────────────────────────────────────────
    test(
      'P4: reAuth.user == null → throw ServerException password tidak sesuai',
      () async {
        // Arrange
        final fakeUser = _fakeUser(id: 'uid1', email: 'agung@mail.com');
        when(() => mockAuth.currentUser).thenReturn(fakeUser);
        when(
          () => mockAuth.refreshSession(),
        ).thenAnswer((_) async => AuthResponse(session: null));
        // signInWithPassword sukses tapi user null di response
        when(
          () => mockAuth.signInWithPassword(
            email: any(named: 'email'),
            password: any(named: 'password'),
          ),
        ).thenAnswer((_) async => AuthResponse(user: null, session: null));

        // Act & Assert
        expect(
          () => dataSource.editProfile(
            oldPassword: 'passwordLama123',
            newPassword: 'passwordBaru456',
          ),
          throwsA(
            isA<ServerException>().having(
              (e) => e.message,
              'message',
              'Password lama tidak sesuai.',
            ),
          ),
        );
      },
    );

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 5: N1 → N2 → N4(true) → N5 → N6 → N8 → N9(ok) → N11 → N12(null) → N21
    // Kondisi : reAuth berhasil, tapi updateUser(password) mengembalikan user null
    // Expected: throw ServerException('Gagal memperbarui password.')
    // ─────────────────────────────────────────────────────────────────────────
    test(
      'P5: updateUser password → result.user null → throw ServerException',
      () async {
        // Arrange
        final fakeUser = _fakeUser(id: 'uid1', email: 'agung@mail.com');
        final mockUserResponse = MockUserResponse();

        when(() => mockAuth.currentUser).thenReturn(fakeUser);
        when(
          () => mockAuth.refreshSession(),
        ).thenAnswer((_) async => AuthResponse(session: null));
        when(
          () => mockAuth.signInWithPassword(
            email: any(named: 'email'),
            password: any(named: 'password'),
          ),
        ).thenAnswer((_) async => AuthResponse(user: fakeUser, session: null));

        when(() => mockUserResponse.user).thenReturn(null);
        when(
          () => mockAuth.updateUser(any()),
        ).thenAnswer((_) async => mockUserResponse);

        // Act & Assert
        expect(
          () => dataSource.editProfile(
            oldPassword: 'passwordLama123',
            newPassword: 'passwordBaru456',
          ),
          throwsA(
            isA<ServerException>().having(
              (e) => e.message,
              'message',
              'Gagal memperbarui password.',
            ),
          ),
        );
      },
    );

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 6: N1 → N2 → N4(true) → N5 → N6 → N8 → N9(ok) → N11 → N12(ok)
    //         → N13 → N14(skip) → N15(skip) → N16(empty) → N20
    // Kondisi : Password berhasil diperbarui, tidak ada update profil lainnya
    // Expected: void (tidak ada exception)
    // ─────────────────────────────────────────────────────────────────────────
    test(
      'P6: Ganti password sukses, username dan avatarUrl null → void',
      () async {
        // Arrange
        final fakeUser = _fakeUser(id: 'uid1', email: 'agung@mail.com');
        final mockUserResponse = MockUserResponse();

        when(() => mockAuth.currentUser).thenReturn(fakeUser);
        when(
          () => mockAuth.refreshSession(),
        ).thenAnswer((_) async => AuthResponse(session: null));
        when(
          () => mockAuth.signInWithPassword(
            email: any(named: 'email'),
            password: any(named: 'password'),
          ),
        ).thenAnswer((_) async => AuthResponse(user: fakeUser, session: null));

        when(() => mockUserResponse.user).thenReturn(fakeUser);
        when(
          () => mockAuth.updateUser(any()),
        ).thenAnswer((_) async => mockUserResponse);

        // Act & Assert — harus selesai tanpa exception
        await expectLater(
          dataSource.editProfile(
            oldPassword: 'passwordLama123',
            newPassword: 'passwordBaru456',
          ),
          completes,
        );

        verifyNever(() => mockSupabase.from(any()));
      },
    );

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 7: N1 → N2 → N4(false) → N13 → N14(ok) → N15(ok)
    //         → N16(notempty) → N17 → N18 → N19(notempty) → N20
    // Kondisi : Tidak ganti password, update username + avatarUrl, keduanya valid
    // Expected: void (berhasil, DB dan auth metadata diperbarui)
    // ─────────────────────────────────────────────────────────────────────────
    test(
      'P7: Update username dan avatarUrl sukses, tanpa ganti password → void',
      () async {
        // Arrange
        final fakeUser = _fakeUser(id: 'uid1', email: 'agung@mail.com');
        final mockUserResponse = MockUserResponse();

        when(() => mockAuth.currentUser).thenReturn(fakeUser);

        when(() => mockSupabase.from(any())).thenReturn(mockQueryBuilder);
        when(
          () => mockQueryBuilder.update(any()),
        ).thenReturn(mockFilterBuilder);

        // Removed 'async' to return the raw object synchronously, fulfilling Dart types
        when(
          () => mockFilterBuilder.eq(any(), any()),
        ).thenAnswer((_) => mockFilterBuilder);

        when(() => mockUserResponse.user).thenReturn(fakeUser);
        when(
          () => mockAuth.updateUser(any()),
        ).thenAnswer((_) async => mockUserResponse);

        // Act & Assert
        await expectLater(
          dataSource.editProfile(
            username: 'agungBaru',
            avatarUrl: 'https://supabase.example.com/avatar.jpg?t=123',
          ),
          completes,
        );
      },
    );

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 8: N1 → N2 → N4(false) → N13 → N14(ok) → N15(skip)
    //         → N16(notempty) → N17 → N18 → N19(notempty) → N20
    // Kondisi : Hanya update username, avatarUrl null
    // Expected: void (berhasil, hanya username yang diupdate)
    // ─────────────────────────────────────────────────────────────────────────
    test('P8: Update username saja (avatarUrl null) → void', () async {
      // Arrange
      final fakeUser = _fakeUser(id: 'uid1', email: 'agung@mail.com');
      final mockUserResponse = MockUserResponse();

      when(() => mockAuth.currentUser).thenReturn(fakeUser);

      when(() => mockSupabase.from(any())).thenReturn(mockQueryBuilder);
      when(() => mockQueryBuilder.update(any())).thenReturn(mockFilterBuilder);
      when(
        () => mockFilterBuilder.eq(any(), any()),
      ).thenAnswer((_) => mockFilterBuilder);

      when(() => mockUserResponse.user).thenReturn(fakeUser);
      when(
        () => mockAuth.updateUser(any()),
      ).thenAnswer((_) async => mockUserResponse);

      // Act & Assert
      await expectLater(
        dataSource.editProfile(username: 'agungBaru'),
        completes,
      );
    });

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 9: N1 → N2 → N4(false) → N13 → N14(skip) → N15(skip)
    //         → N16(empty) → N20
    // Kondisi : Semua parameter null, tidak ada operasi apapun
    // Expected: void (selesai tanpa operasi DB)
    // ─────────────────────────────────────────────────────────────────────────
    test('P9: Semua parameter null → void tanpa operasi DB', () async {
      // Arrange
      final fakeUser = _fakeUser(id: 'uid1', email: 'agung@mail.com');
      when(() => mockAuth.currentUser).thenReturn(fakeUser);

      // Act & Assert
      await expectLater(dataSource.editProfile(), completes);

      verifyNever(() => mockSupabase.from(any()));
      verifyNever(() => mockAuth.updateUser(any()));
    });

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 10: N1 → N2 → N4(true) → N5 → N6 → N8 → N9(ok) → N11 → N12(ok)
    //          → N13 → N14(ok) → N15(ok) → N16(notempty) → N17 → N18
    //          → N19(notempty) → N20
    // Kondisi : Semua operasi dijalankan: ganti password + update username + avatar
    // Expected: void (berhasil total)
    // ─────────────────────────────────────────────────────────────────────────
    test(
      'P10: Ganti password + update username + avatar sekaligus → void (berhasil total)',
      () async {
        // Arrange
        final fakeUser = _fakeUser(id: 'uid1', email: 'agung@mail.com');
        final mockUserResponse = MockUserResponse();

        when(() => mockAuth.currentUser).thenReturn(fakeUser);
        when(
          () => mockAuth.refreshSession(),
        ).thenAnswer((_) async => AuthResponse(session: null));
        when(
          () => mockAuth.signInWithPassword(
            email: any(named: 'email'),
            password: any(named: 'password'),
          ),
        ).thenAnswer((_) async => AuthResponse(user: fakeUser, session: null));

        when(() => mockUserResponse.user).thenReturn(fakeUser);
        when(
          () => mockAuth.updateUser(any()),
        ).thenAnswer((_) async => mockUserResponse);

        when(() => mockSupabase.from(any())).thenReturn(mockQueryBuilder);
        when(
          () => mockQueryBuilder.update(any()),
        ).thenReturn(mockFilterBuilder);
        when(
          () => mockFilterBuilder.eq(any(), any()),
        ).thenAnswer((_) => mockFilterBuilder);

        // Act & Assert
        await expectLater(
          dataSource.editProfile(
            username: 'agungBaru',
            avatarUrl: 'https://supabase.example.com/avatar.jpg?t=123',
            oldPassword: 'passwordLama123',
            newPassword: 'passwordBaru456',
          ),
          completes,
        );
      },
    );

    // ─────────────────────────────────────────────────────────────────────────
    // PATH 11: N1 → N2 → N4(false) → N13 → N14(ok) → N15(ok)
    //          → N16(notempty) → N17 → N21(catch e general)
    // Kondisi : DB update (.from('user').update) melempar exception umum
    //           (bukan ServerException), ditangkap di catch(e)
    // Expected: throw ServerException('[pesan error]')
    // ─────────────────────────────────────────────────────────────────────────
    test(
      'P11: DB update gagal (general exception) → throw ServerException dari catch',
      () async {
        // Arrange
        final fakeUser = _fakeUser(id: 'uid1', email: 'agung@mail.com');
        when(() => mockAuth.currentUser).thenReturn(fakeUser);

        when(() => mockSupabase.from(any())).thenReturn(mockQueryBuilder);
        when(
          () => mockQueryBuilder.update(any()),
        ).thenThrow(Exception('Connection timeout'));

        // Act & Assert
        expect(
          () => dataSource.editProfile(
            username: 'agungBaru',
            avatarUrl: 'https://supabase.example.com/avatar.jpg',
          ),
          throwsA(isA<ServerException>()),
        );
      },
    );
  }); // end group
}
